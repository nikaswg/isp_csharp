﻿
namespace Lunopark.Core.Entities
{
    public partial class Ticket
    {
        public string AttractionName { get; set; }
        public string EmployeeName { get; set; }
    }
}