﻿namespace ConsoleApp
{
    class Car
    {
        public string NameOwner { get; set; }
        public string ModelCar { get; set; }
        public string NumberCar { get; set; }
    }
}